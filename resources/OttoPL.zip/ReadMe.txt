------------------------------- ENGLISH ----------------------------------------
First of all, thank you very much for wanting to install this Abstract Language,
  you will have a lot of fun with it.

INSTALLATION:
  1) Unpack the OttoPL.zip into any folder of your choice.
  2) Run the Installer.jar and select a suitable location,
       where Otto is to be installed
  3) Click on "Install".
  4) To now execute your Otto file, simply call the command "otto" from a
       new command line

------------------------------- GERMAN -----------------------------------------
Erstmal, vielen Dank dafür, dass du diese Abstrakte Sprache installieren willst,
  du wirst sehr viel Spaß damit haben.

INSTALLATION:
  1) Entpacke die OttoPL.zip in einen beliebigen Order deiner Wahl
  2) Führe die Installer.jar aus, und wähle einen geigneten Ort aus,
       wo Otto installiert werden soll
  3) Klicke auf "Install"
  4) Um nun deine Otto Datei auszuführen rufe einfach in einer neuen
       Kommandozeile den Befehl "otto" aus

------------------------------- FRENCH -----------------------------------------
Tout d'abord, merci beaucoup de vouloir installer ce langage abstrait, vous
  aurez beaucoup de plaisir avec lui.

INSTALLATION :
  1) Décompressez le fichier OttoPL.zip dans le dossier de votre choix.
  2) Lancez le fichier Installer.jar et sélectionnez un emplacement approprié,
       où Otto doit être installé
  3) Cliquez sur "Installer".
  4) Pour exécuter votre fichier Otto, appelez simplement la commande "otto"
       depuis une nouvelle ligne de commande

------------------------------- SPANISH ----------------------------------------
En primer lugar, muchas gracias por querer instalar este Lenguaje Abstracto,
  te divertirás mucho con él.

INSTALACIÓN:
  1) Desempaque el OttoPL.zip en cualquier carpeta de su elección.
  2) Ejecute el archivo Installer.jar y seleccione una ubicación adecuada,
       donde se instalará Otto
  3) Haga clic en "Instalar".
  4) Para ejecutar su archivo Otto, simplemente llame al comando "otto" desde
       una nueva línea de comandos

------------------------------- ITALIAN ----------------------------------------
Prima di tutto, grazie mille per aver voluto installare questo linguaggio
  astratto, vi divertirete molto con esso.

INSTALLAZIONE:
  1) Disimballare OttoPL.zip in una cartella a scelta.
  2) Eseguire il file Installer.jar e selezionare una posizione adatta,
       dove deve essere installato Otto
  3) Cliccare su "Installare".
  4) Per eseguire ora il file Otto, è sufficiente richiamare il comando "otto"
       da una nuova riga di comando.

------------------------------- DUTCH ------------------------------------------
Ten eerste, dank u zeer voor het installeren van deze Abstracte Taal, u zult er
  veel plezier mee hebben.

INSTALLATIE:
  1) Pak de OttoPL.zip uit in een map naar keuze.
  2) Voer de Installer.jar uit en selecteer een geschikte locatie,
         waar Otto moet worden geïnstalleerd
  3) Klik op "Installeren".
  4) Om nu uw Otto-bestand uit te voeren, roept u eenvoudigweg het commando
       "otto" op vanaf een nieuwe opdrachtregel

------------------------------- POLISH -----------------------------------------
Przede wszystkim dziękuję bardzo za chęć zainstalowania tego języka
  abstrakcyjnego, będziesz się z nim dobrze bawić.

INSTALACJA:
  1) Rozpakuj OttoPL.zip do dowolnego folderu.
  2) Uruchomić Installer.jar i wybrać odpowiednią lokalizację,
       gdzie ma być zainstalowany Otto
  3) Kliknij na "Install".
  4) Aby teraz wykonać plik Otto, wystarczy wywołać polecenie "otto" z nowej
       linii poleceń
