------------------------------- ENGLISH ----------------------------------------
First of all, thank you very much for wanting to install this Abstract Language, you will have a lot of fun with it.

INSTALLATION:
  1) Unpack the OttoPL.zip into any folder of your choice.
  2) Run the Installer.jar and select a suitable location,
       where Otto is to be installed
  3) Click on "Install".
  4) To now execute your Otto file, simply call the command "otto" from a
       new command line / terminal
  4.1) To start a Otto shell, simply call "ottoS" from a command line / terminal

------------------------------- DEUTSCH -----------------------------------------
Zuerst einmal vielen Dank, dass Sie diese abstrakte Sprache installieren möchten, du wirst viel Spaß dabei haben.

INSTALLATION:
  1) Entpacken Sie die OttoPL.zip in einen beliebigen Ordner Ihrer Wahl.
  2) Führen Sie die Datei Installer.jar aus und wählen Sie einen geeigneten Ort aus,
       wo Otto installiert werden soll
  3) Klicken Sie auf "Installieren".
  4) Um nun Ihre Otto-Datei auszuführen, rufen Sie einfach den Befehl "otto" aus einem
       neue Kommandozeile / Terminal
  4.1) Um eine Otto-Shell zu starten, rufen Sie einfach "ottoS" von einer Kommandozeile / einem Terminal aus auf.

------------------------------- FRANÇAIS -----------------------------------------
Tout d'abord, merci beaucoup de vouloir installer ce langage abstrait, tu t'amuseras beaucoup avec lui.

INSTALLATION :
  1) Décompressez le fichier OttoPL.zip dans le dossier de votre choix.
  2) Lancez le fichier Installer.jar et sélectionnez un emplacement approprié,
       où Otto doit être installé
  3) Cliquez sur "Installer".
  4) Pour exécuter votre fichier Otto, il suffit d'appeler la commande "otto" à partir d'un fichier
       nouvelle ligne de commande / terminal
  4.1) Pour démarrer un shell Otto, il suffit d'appeler "ottoS" depuis une ligne de commande / terminal

------------------------------- PORTUGESA -----------------------------------------
Primeiro de tudo, muito obrigado por querer instalar este Abstract Language, vais divertir-te muito com ele.

INSTALAÇÃO:
  1) Descompacte o OttoPL.zip em qualquer pasta de sua escolha.
  2) Execute o Installer.jar e selecione um local adequado,
       onde será instalado o Otto
  3) Clique em "Instalar".
  4) Para agora executar seu arquivo Otto, basta chamar o comando "otto" de um
       nova linha de comando / terminal
  4.1) Para iniciar uma shell Otto, simplesmente chame "ottoS" de uma linha de comando / terminal

------------------------------- ITALIANO -----------------------------------------
Prima di tutto, grazie mille per aver voluto installare questo linguaggio astratto, ti divertirai un sacco con esso.

INSTALLAZIONE:
  1) Disimballare il file OttoPL.zip in una cartella a scelta.
  2) Eseguire il file Installer.jar e selezionare una posizione adatta,
       dove deve essere installato Otto
  3) Cliccare su "Installare".
  4) Per eseguire ora il file Otto, è sufficiente richiamare il comando "otto" da un file
       nuova linea di comando / terminale
  4.1) Per avviare una shell Otto, è sufficiente chiamare "ottoS" da una linea di comando / terminale.

------------------------------- DUTCH -----------------------------------------
Ten eerste, hartelijk dank voor het willen installeren van deze Abstracte Taal, zal je er veel plezier aan beleven.

INSTALLATIE:
  1) Pak de OttoPL.zip uit in een map naar keuze.
  2) Start de Installer.jar en kies een geschikte locatie,
       waar Otto zal worden geïnstalleerd
  3) Klik op "Installeren".
  4) Om nu uw Otto-bestand uit te voeren, roept u eenvoudigweg het commando "otto" op vanuit een
       nieuwe opdrachtregel / terminal
  4.1) Om een Otto-shell te starten, roept u gewoon "ottoS" op vanaf een commandoregel / terminal.

------------------------------- POLSKA -----------------------------------------
Po pierwsze, dziękuję bardzo za chęć zainstalowania tego abstrakcyjnego języka, będziesz się z tym dobrze bawił.

INSTALACJA:
  1) Rozpakuj OttoPL.zip do dowolnego wybranego folderu.
  2) Uruchomić plik Installer.jar i wybrać odpowiednią lokalizację,
       gdzie Otto ma być zainstalowany.
  3) Kliknij na "Zainstaluj".
  4) Aby teraz wykonać plik Otto, wystarczy wywołać komendę "otto" z
       nowy wiersz poleceń / terminal
  4.1) Aby uruchomić powłokę Otto, wystarczy wywołać "ottoS" z wiersza poleceń / terminala

------------------------------- РОССИАН -----------------------------------------
Прежде всего, большое спасибо за желание установить этот язык абстракции, тебе будет очень весело с этим.

ИНСТАЛЛЯЦИЯ:
  1) Распакуйте файл OttoPL.zip в любую папку по вашему выбору.
  2) Запустите файл Installer.jar и выберите подходящее место,
       где будет установлен Отто.
  3) Нажмите кнопку "Установить".
  4) Чтобы теперь выполнить свой файл Otto, просто вызовите команду "otto" из команды
       новая командная строка / клемма
  4.1) Чтобы запустить Otto shell, просто вызовите "ottoS" из командной строки / терминала.